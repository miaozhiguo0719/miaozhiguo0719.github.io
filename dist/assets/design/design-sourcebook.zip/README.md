# 苗志国 / 自主设计概念 / 2026.10

## WAIST / 腰平相机
创意提出：苗志国。界面设计、交互原型与展示制作：AI 协作。
概念：iPhone Duo 折至 90°，竖起一侧背面镜头朝前，平放内屏朝上取景。常用操作集中在下半屏，上半屏压暗。
包含：使用姿态主视觉、三个宽屏 UI 状态、可操作网页原型。
原型支持胶片模拟切换、EV 调整、拍摄、缩略图回看及保存演示照片。
固定摄影素材用于演示，没有调用真实相机；未宣称已开发原生 App 或存在官方合作。
CLASSIC 400 / FADE 200 / MONO 100 是原创色彩预设名，不代表真实感光度或真实胶片模拟精度。
设备：Apple 官方摄影。界面：本项目原创。取景摄影：苗志国。
界面逻辑研究：NOMO https://nomoshoot.com/ 、FIMO https://fimo.app/ ，未复制其界面或胶片皮肤。
产品参考：https://www.apple.com/iphone-duo/
主视觉使用的官方原图：https://www.apple.com/v/iphone-duo/e/images/overview/product-viewer/laptop__c7kl6vmsqd6q_large_2x.jpg

## Nothing Phone (3) / 不必把不同，藏起来。
自主视觉与包装概念，AI 协作；非品牌委托。
以真实产品背板的三个连续图像平面错位，表达可见结构与个性。
包含：主视觉、包装套封与信息卡平面、可编辑 SVG。
这是图像视觉分解，不是真实拆机或内部工程图。包装为视觉概念，并非生产刀模。
官方产品照片：https://nothing.tech/products/phone-3
确切图源：https://cdn.shopify.com/s/files/1/0376/5420/0459/files/0000s_0011_Phone-3-white.png?v=1753434595

## 打开与修改
artwork/ 内是高分辨率 PNG；source/ 内是可编辑 HTML 或 SVG。
HTML 画面保留文字、排版和图像层；SVG 可在矢量软件中继续修改。
中文字体使用 PingFang SC / Hiragino Sans GB；跨系统需替换同类字体。
prototype/ 为便携网页原型。建议在该目录运行 python3 -m http.server 8000，然后浏览 http://127.0.0.1:8000/ 。
网页原型也已放入个人网站：https://miaozhiguo0719.github.io/waist-demo.html
本包仅收录最终选定作品，不含被放弃的生成设备图。
