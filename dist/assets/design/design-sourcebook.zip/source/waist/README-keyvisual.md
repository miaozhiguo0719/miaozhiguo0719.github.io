# WAIST / 腰平相机 — 原生交互概念主视觉

## Deliverables
- `waist-keyvisual.html`: self-contained editable HTML, 2400 × 1600.
- `waist-keyvisual.png`: inspected rendered export, 2400 × 1600.
- `waist-keyvisual-quads.json`: source coordinates, native transforms and composition placement.
- `build-keyvisual.py`: rebuilds the HTML from the first native screen in `waist-ui-study.html`.
- `render-keyvisual.cjs`: renders the HTML in headless Chrome.

The existing UI-study HTML/PNG and README were not overwritten. The key visual uses the actual first screen from that study.

## Concept
“低头。看见另一种视角。”

At a 90-degree fold, the proposed software moves the viewfinder and camera controls to the lower inner display. The upper display stays quiet, giving a small mode status and the instruction “使用下方屏幕取景”. This is an independent software concept, not an official application or a claim of implemented camera behavior.

The official camera-facing seated pose preserves the physical product. The lower UI is intentionally subject to the photograph's real foreshortening; the separate flat UI study provides legible controls for product review.

## Official image
Page: https://www.apple.com/iphone-duo/

Exact source: https://www.apple.com/v/iphone-duo/e/images/overview/product-viewer/laptop__c7kl6vmsqd6q_large_2x.jpg

Local source: `../commercial-assets/duo-official-seated-2x.jpg`

Image dimensions: 2880 × 1520. Hardware geometry and source pixels are unchanged. The official photo is embedded as a data URL. Native CSS multiply blends the white photographic background onto the board's white background.

## Native UI source
Confirmed first screen in `waist-ui-study.html`:
- Board x = 80, y = 325.
- Width = 1100, height = 500.
- Selector: `.screen.camera`.

The exact section and its original CSS are embedded directly as native HTML inside the lower projected screen. It is not a screenshot pasted over the phone.

## Screen mapping
Coordinates are original photograph pixels, ordered top-left, top-right, bottom-right, bottom-left.

Upper overlay:
`[[1388,284],[2476,284],[2476,1027],[1388,1027]]`

Lower overlay:
`[[1384,1049],[2480,1049],[2562,1197],[1304,1197]]`

The upper overlay extends a few pixels into the black hinge border to eliminate the original space-video edge. It is rounded at the top by 90 native pixels; lower corners are square near the hinge. The lower overlay uses 23-pixel front-corner rounding before its projective transform.

The build script solves the 8-unknown planar homography and encodes it as a native CSS `matrix3d`. Both screen overlays and the original photo share one scaled coordinate space:
- Crop placement: left 990, top 426, width 1330, height 1050.
- Original-photo world: left -1180, top -180, scale 0.94.

## Editing and rebuilding
1. Edit copy, layout and device placement in `build-keyvisual.py`, or edit the resulting HTML directly.
2. For UI edits, change `waist-ui-study.html` and rebuild.
3. Run `python3 build-keyvisual.py`.
4. Run the bundled Node executable with `render-keyvisual.cjs`.

## Visual verification
The final PNG was inspected after a refinement pass. The hero headline is 80 / 78 pixels on a pure white canvas with a restrained hardware-context label:
- No original space content remains visible.
- Upper and lower overlays stay inside the physical display areas.
- Bezel, titanium edge and lower front lip remain visible.
- The source white photo background matches the pure white canvas; native blending preserves the context.
- All embedded images loaded successfully.
- Export is exactly 2400 × 1600.

No image generation, new 3D device construction, site/dist editing or publishing was used.


## Flat UI inset refinement
The same first native camera screen is repeated as an editable flat inset at x96 / y1104, scaled to 792 × 360 (0.72). Its label is “下半屏 / 界面平视图”. The inset makes the software immediately legible while the official front angle explains the physical pose. Metadata was moved below the inset, with no overlap of the device. The PNG was re-rendered and inspected after this final refinement.
