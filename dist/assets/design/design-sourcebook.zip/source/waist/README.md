# 腰平 / WAIST — Original lower-display camera interface

Three wide native interface studies for waist-level photography when a folding device sits at roughly 90 degrees. This is original software concept work, not a claim that a real application or hardware integration is available.

## Deliverables and geometry

- `waist-ui-study.html` — self-contained editable HTML/CSS/JS board; 2400 × 1600 px.
- `waist-ui-study.png` — rendered board.
- Each interface is 1100 × 500 px; finder at x24/y24, width620/height452; right thumb rail at x684/y24, width388/height452.
- Camera board position x80/y325; film presets x1220/y325; exposure tools x80/y1000.
- App charcoal `#171918`, ivory `#eee9dd`, divider `#424640`, muted amber `#b99b64`. Board paper `#e9e6de`.
- Typeface: Helvetica Neue / PingFang SC for labels, Menlo for settings and readouts.

The camera view emphasizes a 4:3-like image region, right-hand film selection, EV, ISO AUTO, AE-L, a large shutter, gallery thumbnail, and session frame count. The film selector labels CLASSIC 400, FADE 200, MONO 100 as original color-look names; these are not physical ISO claims. Exposure tools keep automatic ISO and shutter readouts separate from EV. No adjustable-aperture control is invented.

Prototype interactions: exposure range controls update EV; the shutter flashes the finder and increments the session count; choosing a preset updates selection and the color preview; reset returns EV to zero. This does not access a camera. Values are illustrative UI states rather than the photo's EXIF.

## Primary references checked live

- NOMO official: https://nomoshoot.com/ — point-and-shoot minimalistic analog-camera positioning. Informs restraint and a finder-first hierarchy, without copying a camera skin.
- FIMO official: https://fimo.app/ — film-emulation workflow; developer App Store: https://apps.apple.com/us/app/fimo-analog-camera/id1454219307 . Informs deliberate film selection as a separate task, without using its film names or artwork.
- Dazz developer App Store: https://apps.apple.com/us/app/dazz-cam-vintage-camera/id1422471180 — developer-listed tools include EV, ISO, shutter, grids, and retaining a negative for later adjustment. Informs clearly labeled exposure tools and preserving the original image.

The design uses only those interaction principles. It does not reproduce NOMO, FIMO, Dazz, Nikon, Hasselblad, or another camera brand's actual interface.

## Photography

苗志国：《窗台与午后》 (`08-old-building.webp`) and 《树下的光》 (`11-tree-light.webp`), provided portfolio photography in `dist/assets/photos/`. Photographs are embedded in the HTML. The viewfinder crops for the UI frame; the film panel demonstrates CSS color looks. No new location, date, equipment, or capture metadata is asserted.
