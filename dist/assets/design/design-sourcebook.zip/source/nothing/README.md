# Nothing Phone (3) — 不必把不同，藏起来。

Original commercial visual and packaging study using the genuine Nothing Phone (3), White rear-view product photograph. Independent concept; not commissioned or released by Nothing. The product photo is separated into three continuous horizontal viewing planes; the middle plane is translated sideways. This is explicitly a photographic visual decomposition, not a depiction of actual hardware teardown.

## Sources

- Official product page: https://nothing.tech/products/phone-3
- Exact image link observed on that page: https://cdn.shopify.com/s/files/1/0376/5420/0459/files/0000s_0011_Phone-3-white.png?crop=center&height=144&v=1753434595&width=144
- Native-resolution image downloaded by removing the thumbnail sizing parameters: https://cdn.shopify.com/s/files/1/0376/5420/0459/files/0000s_0011_Phone-3-white.png?v=1753434595
- Downloaded file: `../commercial-assets/nothing-phone3-white.png` — 2048 × 2048, RGBA, transparent background. The original file is embedded byte-for-byte unchanged in each SVG. Source-range clips create three continuous photographic planes; no component or unseen internal structure is invented.

The official page was checked live on 2026-10-26. Only the model name, white color, and visible physical appearance inform these artworks; no new technical or numeric performance claims are made.

## Deliverables

- `nothing-phone3-keyvisual.png` / `.svg` — 2000 × 2500 px, 4:5 poster.
- `nothing-phone3-packaging.png` / `.svg` — 3200 × 2400 px, flat sleeve faces/spines and insert front/reverse.
- `index.html` — local preview of both native SVG masters.
- `build.py` / `render.cjs` — editable authoring coordinates and Chrome render script.

## Concept

“Nothing to hide” takes the phone's already visible geometry as the protagonist. The photo is cut into three continuous viewing planes and the middle plane shifts out of alignment, so difference becomes a compositional act. Fine red seams expose the displaced edges. Chinese copy reads “不必把不同，藏起来。” A black field keeps the white back recognizable, while the packaging repeats the same photographic separation across the sleeve face and a red spine connects the graphic system to the phone's real red marker.

All layout shapes, type, guides, and custom dot-lettering remain editable. Mono and Latin sans fonts are embedded. Chinese live text uses Hiragino Sans GB / PingFang SC. Packaging fold guides are a separate named layer. This is graphic artwork for an independent concept, without production dimensions or a manufacturing-ready die specification.
